# While_Multiplication
 Um programa que pergunta um número ao usuário, e mostre sua tabuada completa do fatorial desse número (de 1 até 10).
