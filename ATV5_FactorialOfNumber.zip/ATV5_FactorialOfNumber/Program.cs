﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactorialOfNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* Write a program that calculates the factorial of a number. 
               The user should be prompted to enter the number, and the
               program should print the factorial. */

            Console.WriteLine("Write a number that it will be calculated the factorial of this number");
            int number = int.Parse(Console.ReadLine());
            int factorial = 1;

            for(int i = 1; i <= number; i++)
            {
                factorial *= i;
            }
            Console.WriteLine(number + "! = " + factorial);
            Console.ReadLine();
        }
    }
}
